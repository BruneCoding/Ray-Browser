// Added when this pack was moved to Bloxd shader pack API version 3, which tells
// packs what a block is made of (blockFlags) instead of its id. This gives one
// typical id for each kind of block, so the pack's id checks keep working:
// water 126, lava 1491, glass 106, grass block 4, leaves 101, dirt 2, rocky
// dirt 652, sandstone 38, sand 5, magma 471, stone 28, lamp 124, planks 15.
fn upgradedBlockId(flags: u32) -> u32 {
#ifdef BLOXD_SCENE_DEPTH
    return 126u;
#else
    if ((flags & bloxdBlockFlagOpaque) == 0u) {
        return select(106u, 1491u, (flags & bloxdBlockFlagEmissive) != 0u);
    }
    if ((flags & bloxdBlockFlagVegetation) != 0u) {
        return select(101u, 4u, (flags & bloxdBlockFlagDirt) != 0u);
    }
    if ((flags & bloxdBlockFlagDirt) != 0u) {
        return select(2u, 652u, (flags & bloxdBlockFlagRock) != 0u);
    }
    if ((flags & bloxdBlockFlagSand) != 0u) {
        return select(5u, 38u, (flags & bloxdBlockFlagRock) != 0u);
    }
    if ((flags & bloxdBlockFlagRock) != 0u) {
        return select(28u, 471u, (flags & bloxdBlockFlagEmissive) != 0u);
    }
    return select(15u, 124u, (flags & bloxdBlockFlagEmissive) != 0u);
#endif
}
