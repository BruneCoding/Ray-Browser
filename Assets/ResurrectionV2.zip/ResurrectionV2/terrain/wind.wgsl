// Wind settings shared by the leaf shimmer, the drifting sunspots and the grass gusts in sunShade.wgsl. Nothing here
// moves blocks: that only runs in a few games, so the wind is all colour and works everywhere.

const WIND_STRENGTH = 1.0;   // 0 stills the leaf shimmer
const WIND_SPEED = 0.8;

fn isLeaf(id: u32) -> bool {
    switch id {
        case 100u, 101u, 102u, 103u, 209u, 210u, 491u, 492u, 493u, 494u, 653u, 911u, 1226u, 1636u, 1969u,
             2019u, 2020u, 2021u, 2022u, 2023u, 2024u, 2025u, 2085u: {
            return true;
        }
        default: {
            return false;
        }
    }
}
