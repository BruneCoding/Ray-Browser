// The soft, misty look: each block's pixel speckle is smoothed towards an even brightness, and soft cloudy blotches
// drift over it instead, fixed to the world. Its colour stays, so grass is still grass and stone is still stone.
// The blotches are finer than a pixel far away, so they fade out there and cost nothing; the finest layer is only
// worked out close up.

const SOFTEN = 0.12;      // how much of the texture's speckle is smoothed out; 0 leaves textures as they are
const SOFT_LEVEL = 0.5;   // the brightness smoothed blocks settle towards
const MIST = 0.16;        // how strong the blotches are
const MIST_SIZE = 5.0;    // blotches across one block
const MIST_FAR = 48.0;    // blocks away where the blotches have faded out
const GRAIN_NEAR = 14.0;  // blocks away where the finest layer stops

// A light integer hash: one multiply-and-shift round is plenty for soft blotches.
fn mistCell(i: vec2i, layer: u32) -> f32 {
    var h = (bitcast<u32>(i.x) * 0x27d4eb2du) ^ (bitcast<u32>(i.y) * 0x165667b1u) ^ (layer * 0x9e3779b9u);
    h = (h ^ (h >> 15u)) * 0x2c1b3c6du;
    h ^= h >> 13u;
    return f32(h >> 8u) / 16777216.0;
}

fn mistNoise(p: vec2f, layer: u32) -> f32 {
    let i = vec2i(floor(p));
    let f = fract(p);
    let u = f * f * (3.0 - 2.0 * f);
    let a = mix(mistCell(i, layer), mistCell(i + vec2i(1, 0), layer), u.x);
    let b = mix(mistCell(i + vec2i(0, 1), layer), mistCell(i + vec2i(1, 1), layer), u.x);
    return mix(a, b, u.y);
}

// The face's own two axes, so blotches lie flat on every side of a block.
fn faceAxes(position: vec3f, normal: vec3f) -> vec2f {
    let a = abs(normal);
    if (a.y > 0.5) {
        return position.xz;
    }
    if (a.x > 0.5) {
        return position.zy;
    }
    return position.xy;
}

fn soften(colour: vec3f, position: vec3f, normal: vec3f) -> vec3f {
    let grey = max(dot(colour, vec3f(0.2126, 0.7152, 0.0722)), 0.001);
    let tint = min(colour / grey, vec3f(4.0));
    let evened = mix(grey, mix(SOFT_LEVEL, grey, 0.35), SOFTEN);

    let dist = distance(bloxdEyePosition(), position);
    let near = 1.0 - smoothstep(MIST_FAR * 0.6, MIST_FAR, dist);
    if (near <= 0.0) {
        return tint * evened;
    }
    let shift = faceAxes(vec3f(bloxdRenderOffset() % vec3i(4096)), normal);
    let p = (faceAxes(position, normal) + shift) * MIST_SIZE;
    var blotch = mistNoise(p, 0u) * 0.625 + mistNoise(p * 2.3, 1u) * 0.375;
    if (dist < GRAIN_NEAR) {
        let grain = mistNoise(p * 5.1, 2u);
        blotch = mix(blotch, grain, 0.2 * (1.0 - smoothstep(GRAIN_NEAR * 0.6, GRAIN_NEAR, dist)));
    }
    return tint * max(evened * (1.0 + (blotch - 0.5) * MIST * 2.0 * near), 0.0);
}
