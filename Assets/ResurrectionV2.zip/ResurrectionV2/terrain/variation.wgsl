// Texture variation: a slight, world-fixed brightness offset per block and per 8x8 shading cell, so large areas of one
// block don't look stamped, then the soft look from soft.wgsl. A surface hook, so it only recolours and runs in strict
// games too.

const BLOCK_VARIATION = 0.04;   // the most a block's brightness is moved either way
const CELL_VARIATION = 0.06;    // and each cell's, on top
const CELL_FAR = 40.0;          // blocks away where the per-cell grain, smaller than a pixel by then, stops

fn bloxdTerrainSurface(surface: BloxdSurfaceIn) -> BloxdSurface {
    let block = bloxdFragmentBlockPosition(surface.position, surface.normal);
    var offset = (hashUnit(cellHash(block)) * 2.0 - 1.0) * BLOCK_VARIATION;
    let cellWeight = 1.0 - smoothstep(CELL_FAR * 0.6, CELL_FAR, distance(bloxdEyePosition(), surface.position));
    if (cellWeight > 0.0) {
        // Half a cell inside the face, so the face's own block decides, not the one beside it. Offset in y so a
        // cell never shares its hash with a block.
        let cell = vec3i(floor(surface.position * f32(CELLS_PER_BLOCK) - surface.normal * 0.5))
            + bloxdRenderOffset() * CELLS_PER_BLOCK + vec3i(0, 104729, 0);
        offset += (hashUnit(cellHash(cell)) * 2.0 - 1.0) * CELL_VARIATION * cellWeight;
    }

    var out = bloxdDefaultSurface(surface);
    out.colour = soften(surface.colour * (1.0 + offset), surface.position, surface.normal);
    return out;
}
