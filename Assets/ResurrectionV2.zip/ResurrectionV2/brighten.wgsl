// Breeze by Crownix, built on Ellie's Shaders by whoisEllie: her water, ripples, sun shade and hashes are the base.

// A brightness lift, applied by both light hooks to the lit colour before fog. It raises darks and mid-tones and
// leaves white at white, so bright blocks don't clip, then gives dull colours a little more colour.

const BRIGHTEN = 1.45;   // 1 leaves colour as it is; the slope at black
const VIBRANCE = 0.22;   // extra colour for dull pixels; already-strong colours are left nearly alone

fn brighten(colour: vec3f) -> vec3f {
    let lifted = max(colour, vec3f(0.0));
    let bright = lifted * BRIGHTEN / (1.0 + lifted * (BRIGHTEN - 1.0));
    let grey = dot(bright, vec3f(0.2126, 0.7152, 0.0722));
    let chroma = max(bright.r, max(bright.g, bright.b)) - min(bright.r, min(bright.g, bright.b));
    return clamp(mix(vec3f(grey), bright, 1.0 + VIBRANCE * (1.0 - chroma)), vec3f(0.0), vec3f(1.0));
}
